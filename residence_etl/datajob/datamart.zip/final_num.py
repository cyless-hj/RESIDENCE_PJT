from infra.jdbc import DataMart, DataWarehouse, find_data, save_data
from pyspark.sql.functions import col, ceil
import pandas as pd
from infra.util import std_day


class SubSampleDataMart:

    @classmethod
    def save(cls):
        loc = find_data(DataWarehouse, 'LOC')
        loc = loc.select('DONG_CODE', 'DONG')
        pd_loc = loc.toPandas()

        subway = find_data(DataMart, 'SUBWAY')
        subway = subway.select('DONG_CODE', 'DONG')
        subway_g = subway.groupby(subway.DONG_CODE, subway.DONG).count()
        subway_g = subway_g.withColumnRenamed('count', 'SUBWAY_NUM')
        pd_sub_way = subway_g.toPandas()

        pd_tot = pd.merge(pd_loc, pd_sub_way, on=['DONG_CODE', 'DONG'], how='outer')

        starbucks = find_data(DataMart, 'STARBUCKS')
        starbucks = starbucks.select('DONG_CODE', 'DONG')
        starbucks_g = starbucks.groupby(starbucks.DONG_CODE, starbucks.DONG).count()
        starbucks_g = starbucks_g.withColumnRenamed('count', 'STARBUCKS_NUM')
        pd_starbucks = starbucks_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_starbucks, on=['DONG_CODE', 'DONG'], how='outer')

        sport = find_data(DataMart, 'SPORT_FACILITY')
        sport = sport.select('DONG_CODE', 'DONG')
        sport_g = sport.groupby(sport.DONG_CODE, sport.DONG).count()
        sport_g = sport_g.withColumnRenamed('count', 'SPORT_NUM')
        pd_sport = sport_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_sport, on=['DONG_CODE', 'DONG'], how='outer')

        safed = find_data(DataMart, 'SAFE_DELIVERY')
        safed = safed.select('DONG_CODE', 'DONG')
        safed_g = safed.groupby(safed.DONG_CODE, safed.DONG).count()
        safed_g = safed_g.withColumnRenamed('count', 'SAFE_DLVR_NUM')
        pd_safed = safed_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_safed, on=['DONG_CODE', 'DONG'], how='outer')

        mcdonalds = find_data(DataMart, 'MCDONALDS')
        mcdonalds = mcdonalds.select('DONG_CODE', 'DONG')
        mcdonalds_g = mcdonalds.groupby(mcdonalds.DONG_CODE, mcdonalds.DONG).count()
        mcdonalds_g = mcdonalds_g.withColumnRenamed('count', 'MC_NUM')
        pd_mcdonalds = mcdonalds_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_mcdonalds, on=['DONG_CODE', 'DONG'], how='outer')

        kinder = find_data(DataMart, 'KINDERGARTEN')
        kinder = kinder.select('DONG_CODE', 'DONG')
        kinder_g = kinder.groupby(kinder.DONG_CODE, kinder.DONG).count()
        kinder_g = kinder_g.withColumnRenamed('count', 'KINDER_NUM')
        pd_kinder = kinder_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_kinder, on=['DONG_CODE', 'DONG'], how='outer')

        kidsc = find_data(DataMart, 'KIDS_CAFE')
        kidsc = kidsc.select('DONG_CODE', 'DONG')
        kidsc_g = kidsc.groupby(kidsc.DONG_CODE, kidsc.DONG).count()
        kidsc_g = kidsc_g.withColumnRenamed('count', 'KIDS_NUM')
        pd_kidsc = kidsc_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_kidsc, on=['DONG_CODE', 'DONG'], how='outer')

        gym = find_data(DataMart, 'GYM')
        gym = gym.select('DONG_CODE', 'DONG')
        gym_g = gym.groupby(gym.DONG_CODE, gym.DONG).count()
        gym_g = gym_g.withColumnRenamed('count', 'GYM_NUM')
        pd_gym = gym_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_gym, on=['DONG_CODE', 'DONG'], how='outer')

        golf = find_data(DataMart, 'GOLF')
        golf = golf.select('DONG_CODE', 'DONG')
        golf_g = golf.groupby(golf.DONG_CODE, golf.DONG).count()
        golf_g = golf_g.withColumnRenamed('count', 'GOLF_NUM')
        pd_golf = golf_g.toPandas()

        pd_tot = pd.merge(pd_tot, pd_golf, on=['DONG_CODE', 'DONG'], how='outer')
        
        pd_tot = pd_tot.fillna(0)
        pd_tot = pd_tot.astype({'SUBWAY_NUM':'int', 'STARBUCKS_NUM':'int', 'SPORT_NUM':'int', 'SAFE_DLVR_NUM':'int', 'MC_NUM':'int', 'KINDER_NUM':'int', 'KIDS_NUM':'int', 'GYM_NUM':'int', 'GOLF_NUM':'int'})
        print(pd_tot)
        pd_tot.to_csv('./sample.csv')