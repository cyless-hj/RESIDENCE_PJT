from infra.jdbc import DataMart, DataWarehouse, find_data, save_data
from pyspark.sql.functions import col, ceil

from infra.util import cal_std_day, std_day


class SportDataMart:

    @classmethod
    def save(cls):
        sport = find_data(DataWarehouse, 'SPORT_FACILITY')
        sport = sport.filter(col("STD_DAY") == cal_std_day(1))

        sport_name = find_data(DataWarehouse, 'SPORT_NAME')
        sport_name = sport_name.filter(col("STD_DAY") == std_day())
        sport_name = sport_name.drop(sport_name.STD_DAY) \
                               .drop(sport_name.SPORT_NAME_IDX)

        sport = sport.join(sport_name, on='SPORT_CODE')

        loc = find_data(DataWarehouse, 'LOC')
        sport = sport.join(loc, on='LOC_IDX')

        sport = sport.drop(sport.LOC_IDX)

        save_data(DataMart, sport, 'SPORT_FACILITY')