from infra.jdbc import DataMart, DataWarehouse, find_data, save_data
from pyspark.sql.functions import col, ceil

from infra.util import cal_std_day, std_day


class SubwayDataMart:

    @classmethod
    def save(cls):
        subway = find_data(DataWarehouse, 'SUBWAY')
        subway = subway.filter(col("STD_DAY") == std_day())

        subway_line = find_data(DataWarehouse, 'SUBWAY_LINE')
        subway_line = subway_line.filter(col("STD_DAY") == cal_std_day(1))
        subway_line = subway_line.drop(subway_line.STD_DAY) \
                                 .drop(subway_line.SUBWAY_LINE_IDX) \
                                 .drop(subway_line.SUBWAY_NAME)
        subway = subway.join(subway_line, on='SUBWAY_CODE')

        loc = find_data(DataWarehouse, 'LOC')
        subway = subway.join(loc, on='LOC_IDX')

        subway = subway.drop(subway.LOC_IDX)

        save_data(DataMart, subway, 'SUBWAY')